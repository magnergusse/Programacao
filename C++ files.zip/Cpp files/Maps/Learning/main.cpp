#include <iostream>
#include <map>
using namespace std;
int main() {

map<char, int> map1={
        {'M', 3},
        {'A', 9},
        {'G', 10}
};

map1['y']=13;
pair<char, int> map2('b', 5);
map1.insert(map2);

cout<<map1['b']<<endl;

for( map<char, int>::iterator itr=map1.begin(); itr!=map1.end(); ++itr){

    cout<<(*itr).second<<endl;
}








    return 0;
}
