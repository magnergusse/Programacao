#include <iostream>
#include <string>
using namespace std;
int main() {

    string x;
    string *y= &x;
    cout<< "Greetings:"; cin>>x;


    cout<< x[11]<<endl;
    cout<< y<<endl;
    cout<< *y<<endl;
    cout<< &y <<endl;
/*Pointers can point to other pointers
 *You can redifine a pointer
 *
 * */







    return 0;
}
