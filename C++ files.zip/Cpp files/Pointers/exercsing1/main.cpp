#include <iostream>
#include<string>
using namespace std;
int main() {
    int a[]={1,2,3,4};

    int *head = a;
    cout<<*head<<endl;

    for (int i=0; i<3;i++){
        head= a + i;
        cout<< *head<< endl;

    }


    return 0;
}
