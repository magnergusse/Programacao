#include <cctype>
#include <iostream>
#include <cstring>

using namespace std;
void palavra (string word){
    for(int i=0;i<=word.size(); i++) {
        if((islower(word.at(i))))
            word.at(i)= word.at(i)-32;
        cout << word.at(i) << endl;
    }

}
int main()
{
    string palavra_a_inserir;
    getline(cin, palavra_a_inserir);
    palavra(palavra_a_inserir);

    return 0;
}