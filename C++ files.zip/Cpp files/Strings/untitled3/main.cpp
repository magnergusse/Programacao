#include <cctype>
#include <iostream>
#include <cstring>

using namespace std;

/*string word;
getline(cin, word);
for(int i=0;i<word.size(); i++) {
if((islower(word.at(i))))
word.at(i)= word.at(i)-32;
cout << word.at(i) << endl;
}
*/


int main() {
    string word="teste do replace";
            for
            word.erase(0, 'a');
        cout<<word;



    return 0;
}