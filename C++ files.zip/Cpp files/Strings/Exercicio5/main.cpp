#include <iostream>
using namespace std;
void countdown(){int N;
    do cin>>N;
    while(N<0);
    for(int i=N;i>=0;i--){
        cout<<i;
    }

}



int main(){
    countdown();

    return 0;
}