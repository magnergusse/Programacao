#include <cctype>
#include <iostream>
#include <cstring>

using namespace std;

/*string word;
getline(cin, word);
for(int i=0;i<word.size(); i++) {
if((islower(word.at(i))))
word.at(i)= word.at(i)-32;
cout << word.at(i) << endl;
}
*/


int main()
{
    string word = "ola";
    for(char c : word)

        cout<<word<< endl<< c;

    return 0;
}