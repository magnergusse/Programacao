#include <iostream>
#include<cstring>
#include<string>
using namespace std;

int main() {
    char str1[20] = {'P', 'r', 'a', 't', 'i', 'c', 'a', '\0'};
    char str2[20];
    int  length ;

    strcpy( str2, str1);
    length = strlen(str2);

    cout << "String 1:" << str1 << endl;
    cout << "String 2:" << str2 << endl;
    cout << "Length:" << length << endl;

    return 0;
}
