#include <iostream>
#include <cstring>
using namespace std;


int main() {
    string full_name, address;
    string greeting("Hello, ");
    cout << "Enter your full name: ";
    getline(cin, full_name);
    cout << "Your full name is: " << full_name << endl;
    cout << "Enter your address on separate lines\n";
    cout << "Terminate with ‘$’\n";
    getline(cin, address, '$');
cout<<"Your address is: "<< address;

    return 0;
}
