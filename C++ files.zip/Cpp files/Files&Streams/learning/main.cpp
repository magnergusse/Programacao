#include <iostream>
#include <fstream>
#include "Info_estudantes.h"
using namespace std;

int main() { Student estudante;
    ofstream dados("Lista de estudantes");
    cout << (dados.is_open() ? "haha" : "nah");



dados<<"Estudante:"<<estudante.Nome<<"Magner\n";
dados<<"Nmec:"<<estudante.Nmec<<110180;





dados.close();
    return 0;
}
