//
// Created by MAGNER GUSSE on 1/11/2022.
//

#ifndef LEARNING_INFO_ESTUDANTES_H
#define LEARNING_INFO_ESTUDANTES_H

struct Student {
    int Nmec;
    std::string Nome;
};


Student ask_info(){ Student estudante;
    std::cout<< "informacao do estudante\n";
    std::cout<< "Nome:"; getline(std::cin, estudante.Nome);
    do{std::cout<< "Nmec:"; std::cin>> estudante.Nmec;} while(estudante.Nmec<100000 || estudante.Nmec>999999);
    return estudante;
}


#endif //LEARNING_INFO_ESTUDANTES_H
