//
// Created by MAGNER GUSSE on 1/13/2022.
//

#include <iostream>
#include <fstream>
#include <vector>
#include <set>
using namespace std;
vector<int> armazenar;
set<int>armazenamento;

int main(int argc, char *argv[]){string linha; int soma=0;
    int inteiro;
    ifstream tirar_dados("valores.txt");
    while (tirar_dados>>inteiro){
        if(!(int)inteiro){cout<<"out of range";}
            else {armazenar.push_back(inteiro);}
    //else{
      //  soma++;
    //cout<<"non int found";}
    }
for(int c: armazenar){
    cout<<c<<endl;

}


    return 0;
}



/*cout<<argc<<"-----argc elements"<<endl;
for(int i=0; i<argc; i++){
cout<<argv[i]<<endl;}

ifstream ficheiro("valores.txt"); while (getline(ficheiro, linha))
soma++;


cout<<"there are"<<argc<<"lines in  ";
*/