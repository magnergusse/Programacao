#include <iostream>
#include <string>
#include <vector>
#include <set>
#include <fstream>
using namespace std;


int main() {vector<double>numeros; int i=0;
string filename;
cout<<"Introduza o nome do ficheiro \".txt\":";
    getline(cin, filename);
ifstream valores(filename);

/*cout<<(valores.is_open()? "Abriu" : "Nao abriu");
    while (valores.is_open()){

    }
*/



if(valores.is_open()){
    cout<<"Is open";
    string linha;

    while( getline(valores, linha)){
            numeros.push_back(stod(linha));
    }

} else cout<<"Nao abriu";





//for(auto valor: numeros){cout<<valor<<endl;}
for (auto valor: numeros){
    i+=valor;
}
cout<<i/numeros.size();




    return 0;
}
