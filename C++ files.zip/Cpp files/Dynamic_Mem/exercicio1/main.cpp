#include <iostream>
using namespace std;
int main() {

int valor, i, count=0, soma=0;

cout<<"valore";cin>>valor;
for(i=valor; valor>0; valor--){
    int arr[]{};
    arr[i]=valor;
    cout<<arr[i]<<endl;
    count+=1;
    soma+=valor;
}
float media= soma/count;
cout<<"MEdia="<<media;


    return 0;
}
