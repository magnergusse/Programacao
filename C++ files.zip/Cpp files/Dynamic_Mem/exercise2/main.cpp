#include <iostream>
using namespace std;
struct Time{
    int hora, minuto, segundo;
};
struct Student{
    int Nmec; string Nome;
};

void Operacao_Inteira();
Student inserir_dados();


Time Inserir_tempo() {
    Time tempo1;
    cout << "Hora"; do{cin >> tempo1.hora;}while(tempo1.hora>23 || tempo1.hora<0 );
    cout << "Minuto"; do{cin >> tempo1.minuto;}while(tempo1.minuto>23 || tempo1.minuto<0 );
    cout << "Segundo"; do{cin >> tempo1.segundo;}while(tempo1.segundo>23 || tempo1.segundo<0 );
return tempo1;
}

Time print_tempo(Time *tempo1){

    cout<< "Hora inserida:\n";
    cout<<tempo1->hora<<":";
    cout<<tempo1->minuto<<":";
    cout<<tempo1->segundo<<".";

}

int main() {
    inserir_dados();
    Operacao_Inteira();

    return 0;
}

void Operacao_Inteira() {
    Time tempo1, tempo2;
    tempo1= Inserir_tempo();
    print_tempo(&tempo1);

    tempo2= Inserir_tempo();
    print_tempo(&tempo2);

    cout<<endl<<tempo2.hora- tempo1.hora;
    cout<<endl<<tempo2.minuto- tempo1.minuto;
    cout<<endl<<tempo2.segundo- tempo1.segundo;
}

Student inserir_dados(){
    Student estudante;
    cout<< "NMEC:";cin>>estudante.Nmec;
    cout<< "Nome:";cin>>estudante.Nome;

}