#include <iostream>
using namespace std;
struct dados{
    int nota; int nmec;
};

dados armazenar(){
    dados data;
    cin>> data.nota>>data.nmec;
    int a[6]{ };

            a[0]=data.nmec;
            *a[1]=new int[5];
}
int main() {

        int** a= new int*[3];
        for(int i=0; i<3;++i)
        cin>>a;

    return 0;
}
