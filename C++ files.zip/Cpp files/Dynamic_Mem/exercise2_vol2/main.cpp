#include <iostream>
#include <string>
#include <vector>

using namespace std;
struct tempo_t{
    int hora, minuto, segundo;
};
struct permanencia{
    string Nome;
    tempo_t entrada;
    tempo_t saida;
};
int menu();
vector<permanencia>dados_t;

permanencia opcao1(permanencia);

permanencia diferenca(permanencia){


}







void Escolher(permanencia &Perm);

int main(){permanencia Perm;
    Escolher(Perm);
    Escolher(Perm);

    return 0;
}

void Escolher(permanencia &Perm) {
    switch (menu()) {
    case(1):{ opcao1(Perm); }
    case 2:{"1";}
    case(3):{"2";}
    case(4):{"3";}
    }
}

int menu(){int opcao;
    cout<<"1. Registar\n";
    cout<<"2. Armazenar\n";
    cout<<"3. Media\n";
    cout<<"4. Terminar\n";
    cin>>opcao;
    return opcao;
}
permanencia opcao1(permanencia){permanencia Perm;
    cout<<"Nome:";
    getline(cin, Perm.Nome);
    cout<<"Hora";cin>>Perm.entrada.hora;
    cout<<"Minuto";cin>>Perm.entrada.minuto;
    cout<<"Segundo";cin>>Perm.entrada.segundo;
return Perm;
}

void Armazenar(){permanencia Perm;
    permanencia c = opcao1(Perm);
    for (permanencia c: dados_t) dados_t.push_back(Perm); int i=0, count;
            count+.at(1)
            ;

}