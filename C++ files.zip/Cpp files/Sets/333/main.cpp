#include <iostream>
#include <set>
using namespace std;
int main() {
string test="whatsup";
string find="wassup";
set <char> findletters;

for(int i=0; i<test.length(); i++){
    char letter=test[i];
    findletters.insert(letter);
}
for(int i=0; i<find.length(); i++){
    char letter= find[i];
    findletters.erase(letter);
}

if(findletters.size()>0){cout<< "It does not";
}
else{cout<<"It does"<<endl;}

    return 0;
}
