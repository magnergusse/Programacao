#include<iostream>
#include<set>
using namespace std;
int main (){

    set<char> set1={'a', 'c', 'Z','M', 'G', 'C', 'e'};
    set1.insert('1');
    set1.erase('e');

    if(set1.find('C')== set1.end()){
        cout<<"could not find the letter"<<endl;

    }
    else{
        cout<<"the letter C exists in the set"<<endl;
    }
    for(auto itr=set1.begin(); itr!=set1.end();++itr ){

        cout<< *itr<<endl;
    }













    return 0;
}

