#include <iostream>
using namespace std;
enum list1{
    manga, jambalao, maca, badjia
};
enum list2{
    vaiteembora, pilinhas, papu, jimmys

};
void printlist(list2 a){
    switch(a){
        case papu:
            cout<<"vai ao papu";
            break;

        case pilinhas:
            cout<< "N vai uma pila ai?";
            break;
        case jimmys:
            cout<< "N vai uma ngufra ai?";
            break;
        case vaiteembora:
            cout<< "N vai uma pavarote ai?";
            break;
        default:cout<< "You entered an unknown name";

    }

}

int main() {
   /* cout<< 0<<endl;
    cout<< jambalao<<endl;
    cout<< maca<<endl;
    cout<< badjia<<endl;
    */
    list2 c= pilinhas;
    list2 e(vaiteembora);
   printlist(e);cout<<endl;
   cout<<list2(1);
    return 0;
}