#include <iostream>
using namespace std;

struct rgb_color {
    unsigned int red   : 5; // 5 bits
    unsigned int green : 6; // 6 bits
    unsigned int blue  : 5; // 5 bits
};


int main() {

  rgb_color cores;
  cores.red=6;
  cores.green=9;
  cout<<cores.red;



    return 0;
}
