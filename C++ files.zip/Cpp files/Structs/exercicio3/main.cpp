#include <iostream>
#include <iomanip>
#include<cmath>
using namespace std;
struct Time{
    int hora, minuto, segundo;
};
struct Student{
    int Nmec;
    string nome;};
void Print_time(Time *tempo1 ){

    Time tempo;
    cout<<setprecision(2)<<tempo1->hora<<":";
    cout<<setprecision(2)<<tempo1->minuto<<":";
    cout<<setprecision(2)<<tempo1->segundo;
}
Time Inserir_tempo(){
Time tempo;
cout<<"Hora";cin>>tempo.hora;
cout<<"Minuto";cin>>tempo.minuto;
cout<<"segundo";cin>>tempo.segundo;

while (tempo.hora>23 || 0>tempo.hora){
    cout<<"Hora";cin>>tempo.hora;
}

while (tempo.minuto>59 || 0>tempo.minuto){
    cout<<"Minuto";cin>>tempo.hora;
}
while (tempo.segundo>59 || 0>tempo.segundo){
    cout<<"Hora";cin>>tempo.hora;
}

return tempo;}

void Inserir_estudante(){
    Student stud;
cout<<"Inserir info do estudante:\n";
cout<<"Nome:";getline(cin, stud.nome);
do {cout<<"Nr Mec:"; cin>>stud.Nmec;}
while(stud.Nmec>999999 || stud.Nmec<100000);
}

int main() {
    int hour, minute, second;//Variaveis do tempo de entrada
    int hour2, minute2, second2;//Variaveis do tempo de saida

    Time tempo1;
Inserir_estudante();//Inserir Nome e Nr Mec

tempo1= Inserir_tempo();//Inserir tempo de estrada
    Print_time(&tempo1);

    hour=tempo1.hora;
    minute=tempo1.minuto;
    second=tempo1.segundo;

cout<< "\nHora de Saida:\n";

    Time tempo2;
tempo2= Inserir_tempo();
    Print_time(&tempo2);
    hour2=tempo2.hora;
    minute2=tempo2.minuto;
    second2=tempo2.segundo;

    int hora_p = hour2 - hour, min_p=minute-minute2, sec=second-second2;

    if (hour2<hour){
        cout<<"Impossible";
    }
    if (hour<=hour2) {

        cout << "Tempo presente:\n";
        cout << "horas:" << hora_p << ':';
        cout << "Minutos:" << min_p << ':';
        cout << "Segundos:" << sec << '.';
    }
return 0;
}
