#include <iostream>

using namespace std;

struct date {int day, month, year;};


void printDate( struct date d )
{
    std::cout << d.month << ", " << d.day << ", " <<  d.year;
}


int main() {
/*
    enum Colors1 {black, white};
    enum class Colors2 {red, blue};
    enum Colors1 c;
    c = white;
    cout << c << endl;
    enum Colors2 c2;
    c2 = Colors2::blue;
    cout << static_cast<int>(c2) << endl;*/


    struct w :: date(10,11,2012);
    printDate(w);

    return 0;
}
