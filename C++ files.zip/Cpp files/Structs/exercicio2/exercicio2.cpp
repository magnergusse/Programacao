#include <iostream>
#include<iomanip>
#include<cmath>
using namespace std;

struct Complex{
    double Re, Re1;
    double Im, Im1;
};
void User_input();
void add();
void sub();
void times();
void div();

int main() {
    string operacao;
    cout << "operacao:";
    cin >> operacao;
        User_input();

    if (operacao == "+") {
        add();
    } else if (operacao == "-") {
        sub();
    } else if (operacao == "*") {
        times();
    } else if (operacao == "/") {
        div();
    } else {
        cout << "Operacao invalida";
    }

    return 0;
}
void User_input(){
    Complex nrs;
    cout<<"Imprimir Pontos:\n";
    cout<<"a=";cin>>nrs.Re;cout<<"b=";cin>>nrs.Im;
    cout<<"c=";cin>>nrs.Re1;cout<<"d=";cin>>nrs.Im1;
}
void imprimir(){
    Complex nrs;
    cout<<setprecision(3)<<fixed<<showpos<<"("<<nrs.Re<<";";
    cout<<setprecision(3)<<fixed<<showpos<<nrs.Im<<"i)\n";
    cout<<setprecision(3)<<fixed<<showpos<<"("<<nrs.Re1<<";";
    cout<<setprecision(3)<<fixed<<showpos<<nrs.Im1<<"i)\n";

}

void add(){
    Complex nrs;
    cout<<setprecision(3)<<fixed<<showpos<<"("<<(nrs.Re)+(nrs.Re1)<<";";
    cout<<setprecision(3)<<fixed<<showpos<<(nrs.Im)+(nrs.Im1)<<"i)";
}

void sub(){
    Complex nrs;
    cout<<setprecision(3)<<fixed<<showpos<<"("<<(nrs.Re)-(nrs.Re1)<<";";
    cout<<setprecision(3)<<fixed<<showpos<<(nrs.Im)-(nrs.Im1)<<"i)";
}
void times(){
    Complex nrs;
    cout<<setprecision(3)<<fixed<<showpos<<"("<<(nrs.Re)*(nrs.Re1)<<";";
    cout<<setprecision(3)<<fixed<<showpos<<(nrs.Im)*(nrs.Im1)<<"i)";
}
void div(){
    Complex nrs;
    cout<<setprecision(3)<<fixed<<showpos<<"("<<(nrs.Re)/(nrs.Re1)<<";";
    cout<<setprecision(3)<<fixed<<showpos<<(nrs.Im)/(nrs.Im1)<<"i)";
}
