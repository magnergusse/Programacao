#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include "Dados_estudante.h"
using namespace std;

struct Time {
    int hour, minute, second;
};
char menu();
vector<Time>armazenar;
Time input_time();

void Print_Time(Time *tempo1);

Time permanencia(Time *tempo1, Time *tempo2);

void Condicoes_tempo(const Time &tempo_t);

int main() { string ficheiro;

  /*  cout<<"Insira nome do ficheiro a criar\".txt\""; cin>>ficheiro;
    ofstream dados(ficheiro);
*/


    switch (menu()) {
        case('a'):{ask_info();break;}
        case('b'):{ cout<<"listar info";}
        case('c'):{cout<< "media";}
        case('d'):{break;}

    }

    Student estudante;


    estudante= ask_info();//armazenar dados na variavel


    //dados<<estudante.Nome<<' '<<estudante.Nmec;//armazenar dados no ficheiro





    Time tempo1;
tempo1= input_time();
    Print_Time(&tempo1);

Time tempo2;
tempo2 = input_time();
    Print_Time(&tempo2);
Time tempo_t;
   tempo_t= permanencia(&tempo1, &tempo2);

    armazenar.push_back(tempo_t);
//dados<<tempo_t.hour<<":";
//dados<<tempo_t.minute<<":";
//dados<<tempo_t.second<<".";


cout<<"\nO estudante: "<<estudante.Nome<<">"<<estudante.Nmec<<
" esteve no DETI por "<<tempo_t.hour<<"h"
<<tempo_t.minute<<"m"
<<tempo_t.second<<"s";






//dados.close();
    return 0;
}

/*void Condicoes_tempo(const Time &tempo_t) {//Condicoes para haver tempo de permanencia possivel

    if(tempo_t.hour < 0){cout << "Impossible!";}//Se hora total for menor que zero fica impossivel
    else if(tempo_t.hour==0){//se hora total for igual a zero
        if(tempo_t.minute<0)cout<<"Impossible!";//se hora total for igual a zero e minutos menores que zero impossivel
        else if(tempo_t.minute==0){//se minutos forem iguais a zero
            if(tempo_t.second<0)cout<<"Impossible";//segundos menores que zero, impossivel
        }
    }
}
*/

Time input_time(){
    Time tempo;
//    cout<< "Inserir tempo de entrada:\n";
    do {cout<<"Hora";cin>>tempo.hour;}while(tempo.hour<0 || tempo.hour>23);
    do {cout<<"Minuto"; cin>>tempo.minute;} while(tempo.minute <0 || tempo.minute>=59);
    do {cout<<"Segundo";cin>>tempo.second;} while (tempo.second< 0 || tempo.second>=59);
    return tempo;
}

void Print_Time(Time *tempo1){
    Time tempo;

    cout<<"Hora:"<<tempo1->hour<<endl;
    cout<<"Minuto"<<tempo1->minute<<endl;
    cout<<"Segundo"<<tempo1->second<<endl;
}

Time permanencia(Time *tempo1, Time *tempo2){
    Time tempo;

    //Condicoes para haver tempo de permanencia possivel

    tempo.hour= tempo2->hour- tempo1->hour;
    tempo.minute= tempo2->minute- tempo1->minute;
    tempo.second= tempo2->second- tempo1->second;


    if(tempo.hour < 0){cout << "Impossible!";}//Se hora total for menor que zero fica impossivel
    else if(tempo.hour==0){//se hora total for igual a zero
        if(tempo.minute<0)cout<<"Impossible!";//se hora total for igual a zero e minutos menores que zero impossivel
        else if(tempo.minute==0){//se minutos forem iguais a zero
            if(tempo.second<0)cout<<"Impossible";//segundos menores que zero, impossivel
        }
    }


    return tempo;
}


char menu(){char opcao;
    cout<<"Menu:";
    cout<<"a. Register a student.\n";
    cout<<"b. List information about all the students (name, entrance time, exit time).\n";
    cout<<"c. Calculate the average length of stay in the department.\n";
    cout<<"d. terminate the program.\n";
    cout<<"What do you wish to do?\n";
    cin>> opcao;

    return opcao;
}
