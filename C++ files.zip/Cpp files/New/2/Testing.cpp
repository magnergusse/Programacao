//
// Created by MAGNER GUSSE on 1/13/2022.
//

#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include "Dados_estudante.h"


using namespace std;

int main(){ ifstream dados("dados.txt");
Student estudante;
dados>>estudante.Nome>>estudante.Nmec;

cout<<estudante.Nome;

    return 0;
}