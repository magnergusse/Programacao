//
// Created by MAGNER GUSSE on 1/14/2022.
//

#ifndef INC_2_FUNCOES_TEMPO_H
#define INC_2_FUNCOES_TEMPO_H

using namespace std;
struct Time{
    int hour, minute second;
};




Time permanencia(Time *tempo1, Time *tempo2){
    Time tempo;

    //Condicoes para haver tempo de permanencia possivel

    tempo.hour= tempo2->hour- tempo1->hour;
    tempo.minute= tempo2->minute- tempo1->minute;
    tempo.second= tempo2->second- tempo1->second;


    if(tempo.hour < 0){cout << "Impossible!";}//Se hora total for menor que zero fica impossivel
    else if(tempo.hour==0){//se hora total for igual a zero
        if(tempo.minute<0)cout<<"Impossible!";//se hora total for igual a zero e minutos menores que zero impossivel
        else if(tempo.minute==0){//se minutos forem iguais a zero
            if(tempo.second<0)cout<<"Impossible";//segundos menores que zero, impossivel
        }
    }


    return tempo;
}


#endif //INC_2_FUNCOES_TEMPO_H
