//
// Created by MAGNER GUSSE on 1/10/2022.
//

#ifndef INC_2_DADOS_ESTUDANTE_H
#define INC_2_DADOS_ESTUDANTE_H
#include <string>
#include <fstream>
using namespace std;
struct Student {
    string Nome;
    int Nmec{};

};

Student ask_info(){ Student estudante;
    cout<< "informacao do estudante\n";
    cout<< "Nome:"; cin>> estudante.Nome;
    do{cout<< "Nmec:"; cin>> estudante.Nmec;} while(estudante.Nmec<100000 || estudante.Nmec>999999);
    return estudante;
}



#endif //INC_2_DADOS_ESTUDANTE_H
