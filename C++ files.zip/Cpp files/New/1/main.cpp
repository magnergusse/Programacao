#include <iostream>
#include <vector>
#include <string>
using namespace std;




int main() {

    int a=2, &b=a, *c=&b;
    cout<<a<<endl;
    cout<<*c<<endl;
    cout<<b<<endl;


    return 0;
}
