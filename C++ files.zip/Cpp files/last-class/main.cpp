#include <iostream>
#include <vector>
#include <fstream>
using namespace std;
void bubble_sort(int *a, int size);
int main() {ofstream notes("notes.txt");

int *p;
p= new int[9];
for(int i=0; i<10; i++)p[i]=i+1;//inserir valores no array p
for (int i=0; i<10; i++)cout<<p[i]<<endl;
//criar novo
//criar ciclo para copiar os valores
//apagar o espaco "delete p"
//igualar p e novo

int a[7]={1,8,3,4,5,6,7};
const int elements=7;
 for (int c: a){cout<<c<<endl;}
    bubble_sort(a,elements);
 for(int c: a){ cout<<c<<endl;}
    return 0;
}
void bubble_sort(int *a, int elements){int val;bool ordem= true; ofstream notes;
    for (int i=0; i<elements;i++){

    for (int j=0; j<elements-1;j++){
        if(a[j]>a[j+1]){
            val=a[j+1];
            a[j+1]=a[j];
            a[j]=val;
            ordem= false;
        }
    }if(ordem)notes<<"already sorted";break;
}

}