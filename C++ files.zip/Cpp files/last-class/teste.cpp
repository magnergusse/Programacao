//
// Created by MAGNER GUSSE on 1/22/2022.
//

#include <iostream>
#include <fstream>
#include <string>
#include <algorithm>
using namespace std;

int main(){
    char ch;
    int j;
    double d;
    string str1;
    string str2;
    ifstream infile("notes");
    getline(infile,str1);
    cout<<str1;
    double size=str1.size()/str1.at(0);
for(int i=0; i<str1.size(); i++){
 if (isdigit(str1.at(i))){
     str1.at(i)='*';
 }
}
cout<<str1<<endl;
    reverse(str1.begin(), str1.end());
    cout<<str1;
    replace(infile.)
    return 0;
}
