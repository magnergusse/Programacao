
#include <iostream>
#include <string>
using namespace std;
int main() {
    int contar=0, contar1=0, ischar=0;
    string string1;
getline(cin, string1);

    for(int i=0; i<string1.length(); i++){
        if(isupper(string1.at(i)))
            contar++;
        if (islower(string1.at(i)))
            contar1++;
        if (isalnum(string1.at(i)));
        ischar++;
    }cout<<contar<<endl<<contar1<<endl<<ischar;
/*
    cout<< endl;
    for(int i=0; i< string1.length(); i++){
        char chr= string1[i];
        cout<< chr<<endl;
//definir o char como cada carater do string//
    }
*/
    return 0;
}
