#include <iostream>
#include<iomanip>
#include <cmath>
#include <vector>
using namespace std;
struct valores{int count=-1; double distance;};
typedef struct{
    double y;
    double x;
}point2D_t;


void ler_ponto(point2D_t &ponto);

void contar_vezes(point2D_t &ponto);

int main() {
    point2D_t ponto;
    contar_vezes(ponto);//contar as vezes que foram inseridas coordenadas erradas

    return 0;
}

void contar_vezes(point2D_t &ponto) {
    double soma=0;
    valores values;//valores de distancia e contagem
    while(ponto.x!=0 || ponto.y!=0){
        ler_ponto(ponto);
        values.count++;
        values.distance=sqrt(pow(ponto.x,2)+(pow(ponto.y, 2)));//calcular distancia em cada loop
    cout<<" D="<<values.distance<<endl;


        vector<double> sum{};//Armazena as distancias
        sum.push_back(values.distance);//Insere distancias
        soma+=values.distance;//Acrescenta as distancias
    }
    cout<<"Pontos diferentes de (0;0) sao:"<<values.count<<endl;
    cout<<"soma de distancias: "<<soma<<endl;
    }



void ler_ponto(point2D_t &ponto) {
    cout << "Insere ponto\n";
    cout<<"X=";cin>> ponto.x;
    cout<<"Y=";cin>>ponto.y;
    cout<<"(" << setprecision(3)<<fixed <<showpos<< ponto.x ;
    cout<<";"<<setprecision(3)<<fixed<<showpos<<ponto.y <<")\n";
}
