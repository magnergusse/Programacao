#include <iostream>
#include <iomanip>

using namespace std;
struct point2d{
    double x, y;
};
void Inserir_coordenadas(double x, double y);

void imprimir_while(double x, double y);

int main() {
double x, y;
point2d ponto;
ponto.x=x;
ponto.y=y;
    Inserir_coordenadas(x, y);
    imprimir_while(x, y);

    return 0;
}

 void imprimir_while(double x, double y) {
    point2d ponto; ponto.x=x; ponto.y=y;

     do{
        Inserir_coordenadas( x, y);
        cout << "(" << setprecision(3) << fixed<<showpos<< x << ";" << setprecision(3) <<fixed<<showpos<< y << ")";
    }while(x==0 && y==0);


}

void Inserir_coordenadas(double x, double y) {
    point2d ponto;
    ponto.x=x;
    ponto.y=y;
    cout << "Insere coordenadas\n";
    cout<<"Valor de x: ";cin>>x;
    cout<<"Valor de y: ";cin>>y;

}
