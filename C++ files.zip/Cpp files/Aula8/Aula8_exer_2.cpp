//
// Created by MAGNER GUSSE on 12/6/2021.
//
#include<iostream>
#include<iomanip>
#include<cmath>
using namespace std;
struct Complex{double re; double im;};
void ask_number();


int main(){



    return 0;
}
