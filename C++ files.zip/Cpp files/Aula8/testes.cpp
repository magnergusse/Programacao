//
// Created by MAGNER GUSSE on 12/6/2021.
//

// imag() function
#include <iostream>

// for std::complex, std::real, std::imag
#include <complex>
using namespace std;

// driver function
int main(){

    return 0;
}