//
// Created by MAGNER GUSSE on 21/02/2022.
//Exercicio1 ficha 8 distancia entre pontos
#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
#include <vector>
#include <cmath>
#include<algorithm>
#include <numeric>
#include <ctype.h>
using namespace std;

struct Ponto{
    double ord, abc, dist;

};
vector<double>armazenar;
Ponto inserir_cord(Ponto point);
void calculardist(Ponto &point);
void histograma(vector<double>&armazenar);
void max_min(vector<double>&armazenar);
void saveinfile(vector<double>&armazenar);
int menu();



int main(){

    int opcao; Ponto point;
    do{
        opcao=menu();
        switch(opcao){

            case 1: {
                inserir_cord(point); break;}
            case 2: {
                calculardist(point); break;}
            case 3: {
                histograma(armazenar);break;}
            case 5: {
                max_min(armazenar);break;}
            case 4: {}
            case 6: {
                saveinfile(armazenar);break;}

        }


    }while(opcao!=10);



    return 0;
}

int menu(){int opcao;

    cout<<"Analysis of a sequence of integers\n";
    cout<<"1- Inserir ponto\n"
        <<"2- Calcular distanca entre dois pontos\n"
        <<"3- Histograma\n"
        <<"4- Standard deviation\n"
        <<"5- Max and Minn\n"
        <<"6- Save\n"
        <<"10- End the program\n"
        <<"Choice ->";cin>>opcao;

    return opcao;
}


Ponto inserir_cord(Ponto point){;
    do {
        cout << "Inserir coordenada X: ";
        cin >> point.abc;
    }while(isdigit(point.abc));
    do {
        cout << "Inserir coordenada y: ";
        cin >> point.ord;
    }while(isdigit(point.ord));

    return point;
}

void calculardist(Ponto &point){
    Ponto point1= inserir_cord(point);
    cout<<"Inserir coordenadas do segundo ponto\n";
    Ponto point2= inserir_cord(point);

    point.dist= sqrt( pow((point2.ord-point1.ord), 2) + pow((point2.abc-point1.abc),2));

    armazenar.push_back(point.dist);

}
void histograma(vector<double>&armazenar){

    cout<<"Histograma de distancias:\n";
    for(double c: armazenar){
        cout<<c<<endl;
    }

}

void max_min(vector<double>&armazenar){

    int max= *max_element(armazenar.begin(), armazenar.end());
    int min= *min_element(armazenar.begin(), armazenar.end());

    cout<<"A maior distancia é: "<<max<<" e a menor é : "<<min<<endl;

}

void saveinfile(vector<double>&armazenar){
    ofstream ficheiro; string filename;

    do{
        cout<<"Inserir nome do ficheiro: ";cin>>filename;
        ficheiro.open(filename);

        if(ficheiro.is_open()){cout<<"Good\n";}
        else{cout<<"BAD\n";}
    }while(!ficheiro.is_open());

    for(double c: armazenar){
        ficheiro<<c<<endl;
    }


}