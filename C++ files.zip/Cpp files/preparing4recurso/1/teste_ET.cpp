//Teste 3 ET
// Created by MAGNER GUSSE on 27/02/2022.
//

#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
#include <vector>
#include <cmath>
#include<algorithm>
#include <numeric>
#include <ctype.h>
using namespace std;
struct Estudante{
    string IPadd; int temp;

};
vector<Estudante>dados_est;

int menu();
string readIP();
int read_temp();
void readmeasurements(Estudante &estudante);
void histograma (vector<Estudante>&dados);
void saveinfile(vector<Estudante>&dados);
void print_range(vector<Estudante>&dados);

int main() {
    int opcao; Estudante student;
    do {
        opcao = menu();

        switch (opcao) {
            case (1): {
                readmeasurements(student);break;
            }

            case (2): {
                print_range(dados_est) ;break;}

            case (3): {
                histograma(dados_est);break;}

            case (4): {
                saveinfile(dados_est);break;}

            default: { cout<<"Insert valid option!\n";}


        }



        }
        while (opcao != 0);


        return 0;
    }

int menu(){int opcao;

    cout<<"Analysis of a sequence of integers\n";
    cout<<"1- Insert new measurment\n"
        <<"2- Print per range\n"
        <<"3- HIstogram\n"
        <<"4- Save in file\n"
        <<"0- End the program\n"
        <<"Choice ->";cin>>opcao;

    return opcao;
}
string readIP(){
    string IPaddress; int valid=0;//check validation of the format
    cin.ignore();
 cout<<"IP address must follow the following format (xxxx xxxx xxxx xxxx)\n";

    do {
        cout << "Insert IP adress: ";
            getline(cin, IPaddress);

            if(IPaddress.length()==19 && IPaddress[4]==' ' && IPaddress[9]==' ' && IPaddress[14]==' '){
                for(int i=0; i<19; i++){
                    if(i==4 || i==9 || i==14){break;}

                    else if(isdigit(IPaddress[i])){ valid=1; continue;}

                    else if(!isdigit(IPaddress[i])) valid=0;break;


                }


            }

            else{valid=0;}


    }while(valid==0);

    return IPaddress;
}

int read_temp(){int temp;

    do{cout<<"Temp";
        cin>>temp;
    }while(temp>50 || temp<0);


    return temp;

}


void readmeasurements(Estudante &estudante){

    estudante.temp= read_temp();
    estudante.IPadd= readIP();

    dados_est.push_back(estudante);
}

void histograma (vector<Estudante>&dados){

    for(Estudante c: dados){
        cout<<"Temperatura: "<<c.temp<<" IPaddress: "<<c.IPadd<<endl;
    }

}

void saveinfile(vector<Estudante>&dados){
string filename; ofstream ficheiro;

int temp=read_temp();
    do{
        cout<<"Insert name of file: ";cin>>filename;
        ficheiro.open(filename);

        if(ficheiro.is_open()){
            cout<<"succesfull!\n";}

        else if(!ficheiro.is_open()){
            cout<<"Nope\n";}


    }while(!ficheiro.is_open());

    for(Estudante c: dados){
        if(c.temp>=temp){
        ficheiro<<"Temperatura: "<<c.temp<<" IPaddress: "<<c.IPadd<<endl;
    }
        else continue;
    }
}

void print_range(vector<Estudante>&dados){// imprimir ocorrencias para cada range de temperaturas
    int zeros=0, jide=0, twentie=0, trinta=0;//0-10; 10-20; 20-30; 30-40

    for(Estudante c: dados){
        if(c.temp<10){zeros++;}//<10 contar
        else if(c.temp>=10 && c.temp<20){jide++;}//10-20 contar
        else if(c.temp>=20&& c.temp<30){twentie++;}//20-30 contar
        else if(c.temp>=30){trinta++;}//+30 contar
    }
    cout<<"from 0 to 10: "<<zeros<<" ocurrencies\n";
    cout<<"from 10 to 20: "<<jide<<" ocurrencies\n";
    cout<<"from 20 to 30: "<<twentie<<" ocurrencies\n";
    cout<<"from 30 to 40: "<<trinta<<" ocurrencies\n";

}
