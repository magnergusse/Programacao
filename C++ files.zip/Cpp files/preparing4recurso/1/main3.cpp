//
// Created by MAGNER GUSSE on 17/02/2022.
//
//tempo de permanencia no DETI
#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
#include <vector>
#include <cmath>
#include<algorithm>
#include <numeric>
using namespace std;

struct Time{
    int hora, minuto, segundo;
};
struct estudante{
    string nome; int nmec; Time time1;
};
vector <estudante>storage;
int menu();
Time askTime(Time& tempo);
void askall(vector<estudante> &storage, Time& tempot, estudante& student);
void histograma(vector<estudante>& storage);
void saveinfile(vector<estudante> &storage);
void openfile();
void medias(vector<estudante>&storage);
void imprimirmaior(vector<estudante>&storage);


int main(){
    Time tempot;
    estudante student;

    int opcao;
    do{
        opcao=menu();
        switch(opcao){
            case 1:{
                askall(storage,tempot, student);break;
            }

            case 2:{
                histograma(storage);break;
            }

            case 3:{
                saveinfile(storage);break;
            }

            case 4:{
                 openfile();break;
            }

            case 5:{
                    medias(storage);break;
            }

            case 6:{
                imprimirmaior(storage);break;
            }

            default:{cout<<"Invalid option, Try again\n";}
                if(opcao==0){cout<<"End of program ;)";}
        }

    } while (opcao!=0);


    return 0;
}

int menu(){int opcao;
    cout<< "Bem vindo!\n";
    cout<<"1-Novo Acesso\n";
    cout<<"2-Listagem de acessos\n";
    cout<<"3-Guardar num ficheiro \n";
    cout<<"4-Mostrar ficheiro\n";
    cout<<"5-Imprimir media de tempos\n";
    cout<<"6-Mostrar registos maiores que\n";
    cout<<"0-Terminar O Programa\n";
    cout<<"Choice->";cin >>opcao;

    return opcao;
}

Time askTime(Time& tempo){
    cout<<"Inserir tempo\n";
    do {
        cout << "Hora: ";
        cin >> tempo.hora;
    cout<<"Minuto: ";cin>>tempo.minuto;

    cout<<"Segundo: ";cin>>tempo.segundo;
    }while(24<tempo.hora|| tempo.hora<0 || 59<tempo.minuto || tempo.minuto<0 ||tempo.segundo>59 || tempo.segundo<0 );//condicao para
                                                                                                                    //tempo ser valido

    return tempo;
}


void askall(vector<estudante>&, Time& tempot, estudante& student){

    cout<<"Inserir Nome: ";
    cin.ignore();//ignorar o que estava antes par poder inicializa o getline
    getline(cin, student.nome);

    do{
        cout<<"Inserir Nmec: ";cin>>student.nmec;

        if(student.nmec<100000 || student.nmec>999999){//range do NMEC
            cout<<"Invalid NMEC!\n";
        }
        else if(student.nmec>100000 && student.nmec<999999){
            cout<<"Welcome to DETI!\n";
        }
    }while(student.nmec<100000 || student.nmec>999999);//repetir enuanto nao for valido


    Time tempo1= askTime(tempo1);//tempo de entrada
    Time tempo2= askTime(tempo2);//tempo de saida
tempo1.hora=tempo1.hora*3600;//converter hora para segundos
tempo1.minuto=tempo1.minuto*60;//converter minutos para segundos

tempo2.hora=tempo2.hora*3600;//same
tempo2.minuto=tempo2.minuto*60;//same

int total= (tempo2.hora+tempo2.minuto+tempo2.segundo)-(tempo1.hora+tempo1.minuto+tempo1.segundo);
            //somar os segundos, para saber o tempo total que ficou(em segundos)


tempot.segundo=total%60;//os segundos serao o rsto dessa divisao
tempot.minuto=(total/60)%60;//minutos
tempot.hora=(total/60)/60;//horas

        if(total<0) {//se tempo final for menor
            cout<<"Impossible\n";
        }

        else if(total==0){//se o tempo de permanencia for nulo
            cout<<"Impossible\n";
        }

        else if(total>0){//se o tempo final for maior
                student.time1=tempot;
                storage.push_back(student);//gur=ardar no vetor

                cout<<"Nome:"<<student.nome<<"-"<<"Nmec: "<<student.nmec<<endl;//imprimir
                cout<<"Tempo de permanencia: "<<student.time1.hora<<":"<<student.time1.minuto<<":"<<student.time1.segundo<<endl;
        }

}
void histograma(vector<estudante>&){
            for(estudante c: storage){//iterar o vetor
                cout<<"Nome:"<<c.nome<<"-"<<"Nmec: "<<c.nmec<<endl;
                cout<<"Tempo de permanencia: "<<c.time1.hora<<":"<<c.time1.minuto<<":"<<c.time1.segundo<<endl;
            }

}
void saveinfile(vector<estudante> &){

    string filename;//variavel para inserir nome do ficheiro
    ofstream ficheiro;//output file

                do{
                    cout<<"Inserir Nome do ficheiro: ";cin>>filename;//inserir nome do ficheiro
                    ficheiro.open(filename);
                    if (ficheiro.is_open()){
                        cout<<"Succesfull!\n";//se o ficheiro abrir
                    }
                    else if(!ficheiro.is_open()){//se o ficheiro nao abrir
                        cout<<"Something's not right!\n";
                    }

                }while(!ficheiro.is_open());//ate abrir o ficheiro

                for(estudante c: storage) {
                    ficheiro<<"Nome:"<<c.nome<<"-"<<"Nmec: "<<c.nmec<<endl;
                    ficheiro<<"Tempo de permanencia: "<<c.time1.hora<<":"<<c.time1.minuto<<":"<<c.time1.segundo<<endl<<endl;
                }
ficheiro.close();//fechar
}

void openfile(){

    string filename, linha;
    ifstream ficheiro;//input file

    do{
        cout<<"Inserir Nome do ficheiro: ";cin>>filename;
        ficheiro.open(filename);//abrir
        if (ficheiro.is_open()){
            cout<<"Succesfull!\n";
        }
        else if(!ficheiro.is_open()){
            cout<<"Something's not right!\n";
        }

    }while(!ficheiro.is_open());//repetir ate abriur

    do{
        getline(ficheiro, linha);//a linha do ficheiro vai ser atribuida a variavel
        cout<<linha<<endl;
    }while(!ficheiro.eof());//enquanto n ao chegar ao fim do ficheiro


    ficheiro.close();//fechar
}

void medias(vector<estudante>&){
    Time media;
 int total=0;
    int count=0;

        for(estudante c: storage){

            total+=(c.time1.hora*3600)+(c.time1.minuto*60)+c.time1.segundo;//somar em segundos


            count++;//contar as vezes que o processo ocorre
        }
        total=total/count;//media
    media.segundo=total%60;//converter para segundos
    media.minuto=(total/60)%60;//minutos
    media.hora=(total/60)/60;//horas

            cout<<"TEmpo medio de estadia:"<<media.hora<<":"<<media.minuto<<":"<<media.segundo<<endl;

}
void imprimirmaior(vector<estudante>&){
    Time tempo= askTime(tempo);//pedir um tempo
    int total= (tempo.hora*3600)+(tempo.minuto*60)+tempo.segundo;//converter para segundos

    for(const estudante& c: storage){
        int temp;
        temp=(c.time1.hora*3600)+(c.time1.minuto*60)+c.time1.segundo;//converter para segundos

        if(temp>=total){//se for maior ou igual ao tempo inserido imprimir
            cout<<"Nome:"<<c.nome<<"-"<<"Nmec: "<<c.nmec<<endl;
            cout<<"Tempo de permanencia: "<<c.time1.hora<<":"<<c.time1.minuto<<":"<<c.time1.segundo<<endl;
        }
        else continue;//se nao for continuar
    }

}