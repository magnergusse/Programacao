//Exercicio 1 ficha 11
#include <iostream>
#include<string>
#include <vector>
#include <fstream>
#include <algorithm>
#include <numeric>
#include <cmath>
using namespace std;


vector<int>valores;
int menu();
void lervalores();
double media(vector<int>&valores);
void maioresquemedia(vector<int>&valores);
double std_dev(vector<int> &valores);
void max_min(vector<int>&valores);

int main() {
int opcao;
    do{
        opcao=menu();

        switch(opcao){
            case (1): { lervalores(); break;}
            case (2): { cout<<"A media e'"; cout<<media(valores)<<endl<<"123\n";break;}
            case (3): {
                maioresquemedia(valores);break;}
            case (4): {
                std_dev(valores);break;}

            case (5): {max_min(valores); break;}
        }



    }while(opcao!=0);




    return 0;
}

int menu(){int opcao;

    cout<<"Analysis of a sequence of integers\n";
    cout<<"1- Histogram\n"
        <<"2- Media\n"
        <<"3- MAiores que a media\n"
        <<"4- Standard deviation\n"
        <<"5- Max and Minn"
        <<"6- Histogram\n"
        <<"10- End the program\n"
        <<"Choice ->";cin>>opcao;

    return opcao;
}


void lervalores(){
    ifstream ficheiro; string filename; string linha;

    do{
        cout<<"Inserir nome do ficheiro: ";
        cin>>filename;
        ficheiro.open(filename);//abrir o ficheiro
        if(ficheiro.is_open()){
            cout<<"File opened\n";

        }
        else cout<<"File not opened\n";

    } while (!ficheiro.is_open());
do {
    getline(ficheiro, linha);

    valores.push_back(stod(linha));//guardar apenas os inteiros
}while(!ficheiro.eof());
    for(int c: valores){
        cout<<c<<endl;
    }


}

double media(vector<int>&valores){
double media;
    double sum;
    sum = accumulate(valores.begin(), valores.end(), 0 );//acumular de begin ate end comecando com 0


    media= sum/valores.size();
return media;
}

void maioresquemedia(vector<int>&valores){

    for(int c: valores){
        if(c > media(valores)){//se for maior que aquilo que a funcao media retorna
            cout<<c<<endl;//imprimir
        }
        else continue;
    }

}

double std_dev(vector<int> &valores){//standard deviation
    double deviation, sum=0, soma; int count=0;

    for(int c: valores){

        soma= c- media(valores);//sample- media
        sum+=pow(soma, 2);//(sample-media)^2 acrescentar na soma
        count++;//numero de samples
    }
    count=count-1;
    deviation= sqrt(sum/count);


    return deviation;

}

void max_min(vector<int>&valores){

    int max= *max_element(valores.begin(), valores.end());
    int min= *min_element(valores.begin(), valores.end());

    cout<<"The maximum value is: "<<max<<" and the minimmum is: "<<min<<endl;


}