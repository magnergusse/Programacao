//Exercicio 5 ficha 10
// Created by MAGNER GUSSE on 27/02/2022.
//

#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
#include <vector>
#include <cmath>
#include<algorithm>
#include <numeric>
#include <ctype.h>
using namespace std;

vector<int>sequencia;
vector<vector<int>>armazenar;
int menu();
void inserir_sequencia();
void histograma(vector<vector<int>>&armazenar);
void max_min(vector<vector<int>>&armazenar);
void media(vector<vector<int>>&armazenar);
void saveinfile(vector<vector<int>>&armazenar);

int main(){
    int opcao;
    do{
        opcao=menu();
        switch(opcao){

                case 1: {
                 break;}

                 case 2: {
                inserir_sequencia(); break;}

                case 3: {
                histograma(armazenar);break;}

                case 5: {
                max_min(armazenar);break;}

                case 4: {
                media(armazenar); break;}
                case 6: {
                saveinfile(armazenar);break;}

        }


    }while(opcao!=10);



    return 0;
}
int menu(){int opcao;

    cout<<"Analysis of a sequence of integers\n";
    cout<<"1- Read a sequence\n"
        <<"2- rite a sequence\n"
        <<"3- HIstogram\n"
        <<"4- Mean value\n"
        <<"5- Calculate the max and min value\n"
        <<"6- Save in file\n"
        <<"10- End the program\n"
        <<"Choice ->";cin>>opcao;

    return opcao;
}

void inserir_sequencia(){int valor;
    cout<<"Inserir sequencia";
    do{
        cin>>valor;
           if(valor!=0){
               sequencia.push_back(valor);}
           else{
               cout<<"Fim da sequencia\n";
               armazenar.push_back(sequencia);
           }
    }while(valor!=0);
sequencia.clear();

}

void histograma(vector<vector<int>>&armazenar){

    for(int i=0; i<armazenar.size(); i++){

        for(int c: armazenar[i]){
            cout<<c<<',';
        }
        cout<<endl;
    }



}
void max_min(vector<vector<int>>&armazenar){
    for(int i=0; i<armazenar.size(); i++){
        int max= *max_element(armazenar[i].begin(),armazenar[i].end());
        int min= *min_element(armazenar[i].begin(),armazenar[i].end());

    cout<<"Max element of"<<i<<" sequence is"<<max<<" and Min element is: "<<min<<endl;
    }


}
void media(vector<vector<int>>&armazenar){double media;
    for(int i=0; i<armazenar.size(); ++i){
        double soma= accumulate(armazenar[i].begin(), armazenar[i].end(), 0);
        media=soma/armazenar[i].size();
        cout<<"A media da "<<i+1<<"sequencia e': "<<media<<endl;
    }


}
void saveinfile(vector<vector<int>>&armazenar){
    ofstream ficheiro; string filename;

    do{
        cout<<"Inserir nome do fichairo: ";cin>>filename;

        ficheiro.open(filename);

        if(ficheiro.is_open()){
            cout<<"GOOD!\n";
        }
        else{
            cout<<"BAD";}

    } while (!ficheiro.is_open());



    for(int i=0; i<armazenar.size(); i++){

        for(int c: armazenar[i]){
            ficheiro<<c<<',';
        }
        ficheiro<<endl;
    }




}