//
// Created by MAGNER GUSSE on 28/02/2022.
//

#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
#include <vector>
#include <cmath>
#include<algorithm>
#include <numeric>
#include <ctype.h>

using  namespace std;

struct Measure{
    double humidade;
    string IP;
};

string filename;

void printMyInfo();
vector<Measure>medidas;
vector<Measure>Medidas_corretas;
void ReadFile( vector<Measure>&medida, string filename);
void media(vector<Measure>&medidas);
void medidasporIP(vector<Measure>&medidas);
void verificarIP(vector<Measure>&medidas,vector<Measure>&Medidas_corretas);
void saveinfile(vector<Measure>&Medidas_corretas, string filename);


int main(){

    Measure measure;
    printMyInfo();

    ReadFile(medidas, filename);
    media(medidas);
    medidasporIP(medidas);
    verificarIP(medidas, Medidas_corretas);
    saveinfile(Medidas_corretas, filename);


    return 0;
}
void printMyInfo(){
    cout<<"Magner Gusse, 110180.\n";
}
void ReadFile( vector<Measure>&medida, string filename){
    ifstream ficheiro; Measure measure;
    do {
        cout << "Inserir nome do ficheiro(.txt):";
        cin>>filename;

        ficheiro.open(filename);

        if (ficheiro.is_open()){
            cout<<"File opened successfully!\n";
        }

        else if(!ficheiro.is_open()){
            cout<<"Please insert a valid filename.\n";
        }


    } while (!ficheiro.is_open());

            do {
                ficheiro >> measure.humidade;
                ficheiro>> measure.IP;

                medidas.push_back(measure);

                if(ficheiro.eof()){
                    cout<<"Completed.\n";
                }

            } while (!ficheiro.eof());
for(Measure c: medidas){
    cout<<c.humidade<<" "<<c.IP<<endl;
}

}

void media(vector<Measure>&medidas){
    double soma=0; int count=0;
    double media;
    for(Measure c: medidas){
        soma+=c.humidade;
        count++;
    }
        if(count==0){
            cout<<"No values.\n";
        } else if(count>0){
        media=soma/count;

        }

    double max= 0;//valor minimo que pode ter
    double min=100;//valor maximo que pode ter

        for(Measure c: medidas){
            if(c.humidade>max){//verificar o maximo
                max=c.humidade;
            }
            else continue;
        }

    for(Measure c: medidas){
        if(c.humidade<min){//verificar o minimo
            min=c.humidade;
        }
        else continue;
    }

if(count>0){
    cout<<"Media das humidades e': "<<media<<endl
        <<"Valor maximo e': "<<max<<endl
        <<"Valor minimo e': "<<min<<endl;
}



}


void medidasporIP(vector<Measure>&medidas){
    string IPadd; double sum=0; int count=0;

    cin.ignore();//para nao afetar o getline a seguir
    cout<<"Inserir IP para verificar: ";cin>> IPadd;
cout<<IPadd<<endl;//inserir IP para verificar


    for(int i=0; i<medidas.size(); i++){//iterar o vector

        if(IPadd==medidas[i].IP){//comparar com o IP inserido
            count++;
            sum+=medidas[i].humidade;

        }

        else continue;
    }

    cout<<"Foram lidos "<<count<<"Valores de humidade no IP "<<IPadd<<"A media e' "<<sum/count<<"%\n";



}

void verificarIP(vector<Measure>&medidas,vector<Measure>&Medidas_corretas){
    int valid;

    for(int i=0; i<medidas.size(); i++){

        if(medidas[i].IP.length()==11 && medidas[i].IP[3]=='.' && medidas[i].IP[7]=='.' && medidas[i].IP[9]=='.'){
                //condicoes a serem verificadas inicialmente

            for(int j=0; j<medidas[i].IP.length(); j++){//iterar o string IP adresss

                if(j==3 || j==7 || j==9) continue;//posicoes em que tem '.'
                else if(isdigit(medidas[i].IP[j]) ) {valid=1; continue;}//verificar se e'digito
                else if(!isdigit(medidas[i].IP[j])) valid=0; break;//se nao for digito quebrar o ciclo e invalida
        }

        }
        else valid=0;//se nao cumprir as condicoes nao e'valido


        if(valid==1){//se for valido armazenar o novo vetor
            Medidas_corretas.push_back(medidas[i]);
        }
        else continue;


    }



}

void saveinfile(vector<Measure>&Medidas_corretas, string filename){
    ofstream ficheiro;


    do{
        cout<<"Insert name of file: ";cin>>filename;
        ficheiro.open(filename);

        if(ficheiro.is_open()){
            cout<<"succesfull!\n";}

        else if(!ficheiro.is_open()){
            cout<<"File not opened\n";}


    }while(!ficheiro.is_open());

    ficheiro<<"Value"<<setw(5)<<"| "<<"IP"<<endl;
    for(Measure c: Medidas_corretas){

            ficheiro<<c.humidade<<setw(5)<<"| "<<c.IP<<endl;
    }
}
