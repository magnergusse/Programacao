//
// Created by MAGNER GUSSE on 16/02/2022.
//
//Desafio 3

#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
#include <vector>
#include <cmath>
#include<algorithm>
#include <numeric>
using namespace std;


struct PontoAcesso{
    int edificio, Piso, Sala;
};
struct Registo{
    int IDcard, dia, mes, ano, hora, minuto, segundo;
    PontoAcesso point;
};

vector<Registo> armazenar;
string filename;
int LeIDCartao();
PontoAcesso LepontoAcesso();
int menu();
void LeAcesso(const Registo&);
void Histograma(vector<Registo>&armaznar);
void imprimirporedificio(vector<Registo>&armazenar);
void imprimirporata(vector<Registo>&armazenar);
void saveinfile(vector<Registo>&armazenar);

int main(){
    cout<<"Magner Gusse, 110180\n";
Registo registo;
int opcao;
do{
    opcao=menu();
    switch(opcao){
        case 1:{
            LeAcesso(registo);break;
        }

        case 2:{
            Histograma(armazenar);break;
        }

        case 3:{
            imprimirporedificio(armazenar);break;

        }
        case 4:{
            imprimirporata(armazenar);break;
        }
        case 5:{
            saveinfile(armazenar);break;
        }
        default:{cout<<"Invalid option, Try again\n";}
        if(opcao==0){cout<<"End of program ;)";}
    }

} while (opcao!=0);


return 0;
}

int menu(){int opcao;
    cout<< "Bem vindo!\n";
    cout<<"1-Novo Acesso\n";
    cout<<"2-Listagem de acessos\n";
    cout<<"3-listagem de Acessos por edificio \n";
    cout<<"4-Listagem de acessos por data/hora\n";
    cout<<"5-Guardar registos\n";
    cout<<"0-Terminar O Programa\n";
    cout<<"Choice->";cin >>opcao;

    return opcao;
}

int LeIDCartao(){int Cardnumb;

    do{
        cout<<"Inserir numero do cartao: ";cin>>Cardnumb;
                if(Cardnumb<=255 && Cardnumb>0){
                    cout<<"succesfull";

                }
                else if(Cardnumb>255 || Cardnumb<=0){
                    cout<<"Not in range, Try again!\n";

                }
    }while(Cardnumb>255 || Cardnumb<=0);

    return Cardnumb;
}

PontoAcesso LepontoAcesso(){PontoAcesso accesspoint{};
    cout<<"Inserir Ponto de Entrada\n";
        do{
            cout<<"Edificio: ";cin>>accesspoint.edificio;
            }while(accesspoint.edificio<0 || accesspoint.edificio>23);

        do{
            cout<<"Piso: ";cin>>accesspoint.Piso;
        }while(accesspoint.Piso<0 || accesspoint.Piso>23);

        do{
            cout<<"Sala: ";cin>>accesspoint.Sala;
        }while(accesspoint.Sala<0 || accesspoint.Sala>23);

    return accesspoint;
}


void LeAcesso(const Registo&){Registo access{};

    cout<<"Inserir Ponto de Entrada\n";
    do{
        cout<<"Edificio: ";cin>>access.point.edificio;
    }while(access.point.edificio<0 || access.point.edificio>23);

    do{
        cout<<"Piso: ";cin>>access.point.Piso;
    }while(access.point.Piso<0 || access.point.Piso>23);

    do{
        cout<<"Sala: ";cin>>access.point.Sala;
    }while(access.point.Sala<0 || access.point.Sala>100);


    do{
        cout<<"Card Number: ";cin>>access.IDcard;
    }while(access.IDcard>255 || access.IDcard<=0);

    do{
        cout<<"Dia: ";cin>>access.dia;
        cout<<"Mes: ";cin>>access.mes;
        cout<<"Ano: ";cin>>access.ano;
        if (access.ano<2000 || access.mes>12 || access.mes<1 || access.dia>31 || access.dia<1){
            cout<<"Invalid Date, Please check again.\n";
        }
    } while (access.ano<2000 || access.mes>12 || access.mes<1 || access.dia>31 || access.dia<1);

    do{
        cout<<"Hora: ";cin>>access.hora;
        cout<<"Minuto: ";cin>>access.minuto;
        cout<<"Segundoo: ";cin>>access.segundo;

        if(access.hora<0 || access.hora>23 || access.minuto<0 || access.minuto>59 || access.segundo<0 || access.segundo>59){
            cout<<"Invalid Time, Check again.\n";
        }

    } while (access.hora<0 || access.hora>23 || access.minuto<0 || access.minuto>59 || access.segundo<0 || access.segundo>59);

armazenar.push_back(access);
}

void Histograma(vector<Registo> &armazenar){
    cout<<"Ponto, Card, Date&Time\n";
    for(Registo c: armazenar){
            cout<<setfill('0')<<setw(2)<< c.point.edificio<<","
                <<setfill('0')<<setw(2)<<c.point.Piso<<","
                <<setfill('0')<<setw(3)<<c.point.Piso<<'-'
                <<c.IDcard<<"-"
                    <<setfill('0')<<setw(2)<<c.ano<<'/'
                    <<setfill('0')<<setw(2)<<c.mes<<'/'
                    <<setfill('0')<<setw(2)<<c.dia<<'-'
                    <<setfill('0')<<setw(2)<<c.hora<<':'
                    <<setfill('0')<<setw(2)<<c.minuto<<':'
                    <<setfill('0')<<setw(2)<<c.segundo<<'.'
                    <<endl;
    }


}

void imprimirporedificio(vector<Registo>&armazenar){
    int edificio;
    do{
        cout<<"Edificio: ";cin>> edificio;

        if(edificio>23 || edificio<=0){
            cout<<"Invalid building\n";
        }
    }while(edificio>23 || edificio<=0);

    for(Registo c :armazenar){
        if(edificio==c.point.edificio){
            cout<<setfill('0')<<setw(2)<< c.point.edificio<<","
                <<setfill('0')<<setw(2)<<c.point.Piso<<","
                <<setfill('0')<<setw(3)<<c.point.Piso<<'-'
                <<c.IDcard<<"-"
                <<setfill('0')<<setw(2)<<c.ano<<'/'
                <<setfill('0')<<setw(2)<<c.mes<<'/'
                <<setfill('0')<<setw(2)<<c.dia<<'-'
                <<setfill('0')<<setw(2)<<c.hora<<':'
                <<setfill('0')<<setw(2)<<c.minuto<<':'
                <<setfill('0')<<setw(2)<<c.segundo<<'.'
                <<endl;


        }

    }

}


void imprimirporata(vector<Registo>&armazenar){
int dia, mes, ano;
    do{
        cout<<"Dia: ";cin>>dia;
        cout<<"Mes: ";cin>>mes;
        cout<<"Ano: ";cin>>ano;
        if (ano<2000 || mes>12 || mes<1 || dia>31 || dia<1){
            cout<<"Invalid Date, Please check again.\n";
        }
    } while (ano<2000 || mes>12 || mes<1 || dia>31 || dia<1);


    for(Registo c: armazenar){
            if(ano<c.ano){
                cout<<setfill('0')<<setw(2)<< c.point.edificio<<","
                    <<setfill('0')<<setw(2)<<c.point.Piso<<","
                    <<setfill('0')<<setw(3)<<c.point.Piso<<'-'
                    <<c.IDcard<<"-"
                    <<setfill('0')<<setw(2)<<c.ano<<'/'
                    <<setfill('0')<<setw(2)<<c.mes<<'/'
                    <<setfill('0')<<setw(2)<<c.dia<<'-'
                    <<setfill('0')<<setw(2)<<c.hora<<':'
                    <<setfill('0')<<setw(2)<<c.minuto<<':'
                    <<setfill('0')<<setw(2)<<c.segundo<<'.'
                    <<endl;
            }
                else if(ano==c.ano){

                    if (mes<c.mes){
                            cout<<setfill('0')<<setw(2)<< c.point.edificio<<","
                            <<setfill('0')<<setw(2)<<c.point.Piso<<","
                            <<setfill('0')<<setw(3)<<c.point.Piso<<'-'
                            <<c.IDcard<<"-"
                            <<setfill('0')<<setw(2)<<c.ano<<'/'
                            <<setfill('0')<<setw(2)<<c.mes<<'/'
                            <<setfill('0')<<setw(2)<<c.dia<<'-'
                            <<setfill('0')<<setw(2)<<c.hora<<':'
                            <<setfill('0')<<setw(2)<<c.minuto<<':'
                            <<setfill('0')<<setw(2)<<c.segundo<<'.'
                            <<endl;

            }
                    else if(mes==c.mes){
                        if(dia<=c.dia){
                            cout<<setfill('0')<<setw(2)<< c.point.edificio<<","
                                <<setfill('0')<<setw(2)<<c.point.Piso<<","
                                <<setfill('0')<<setw(3)<<c.point.Piso<<'-'
                                <<c.IDcard<<"-"
                                <<setfill('0')<<setw(2)<<c.ano<<'/'
                                <<setfill('0')<<setw(2)<<c.mes<<'/'
                                <<setfill('0')<<setw(2)<<c.dia<<'-'
                                <<setfill('0')<<setw(2)<<c.hora<<':'
                                <<setfill('0')<<setw(2)<<c.minuto<<':'
                                <<setfill('0')<<setw(2)<<c.segundo<<'.'
                                <<endl;

                        }
                        else continue;
                    }
                    else continue;
        }
            else continue;

    }

}

void saveinfile(vector<Registo>&armazenar){
    ofstream ficheiro;

    do{
        cout<< "Nome do ficheiro: ";cin>>filename;
        ficheiro.open(filename);

        if(ficheiro.is_open()){cout<<"Succesfull\n";}
        else{cout<<"TRy again\n";}

    }while(!ficheiro.is_open());

    for(Registo c: armazenar){
        ficheiro<<setfill('0')<<setw(2)<< c.point.edificio<<","
                <<setfill('0')<<setw(2)<<c.point.Piso<<","
                <<setfill('0')<<setw(3)<<c.point.Piso<<'-'
                <<c.IDcard<<"-"
                <<setfill('0')<<setw(2)<<c.ano<<'/'
                <<setfill('0')<<setw(2)<<c.mes<<'/'
                <<setfill('0')<<setw(2)<<c.dia<<'-'
                <<setfill('0')<<setw(2)<<c.hora<<':'
                <<setfill('0')<<setw(2)<<c.minuto<<':'
                <<setfill('0')<<setw(2)<<c.segundo<<'.'
                <<endl;
    }

}

