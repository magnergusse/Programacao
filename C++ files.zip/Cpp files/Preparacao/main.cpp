#include <iostream>
#include<string>
#include <vector>
#include <fstream>
#include <algorithm>
#include <numeric>
#include <cmath>
using namespace std;

struct Values{ int number;};//Struct dos inteiros a receber
vector <int> sequencia;//vector que ira receber os inteiros


int menu();
void opcao1();
void opcao2(vector<int> &sequencia);
int opcao3(vector<int> &sequencia);
int opcao4(vector<int> &sequencia);
double opcao5(vector<int> &sequencia);
void opcao6(vector<int> &sequencia);
double opcao7(vector<int> &sequencia);

int main() {
    Values valores;

int opcao;
do {
    opcao=menu();

    switch (opcao) {
                    case (1): {
                            opcao1();
                            break;
                                }
                    case (2): {
                    opcao2(sequencia);
                    break;
                    }

                    case (3): {
                        cout << "O valor maximo e': " << opcao3(sequencia);
                        break;
                    }

                    case (4): {
                        cout << "o valor minimo e'" << opcao4(sequencia) << endl;
                        break;
                    }

                    case (5): {
                        cout << "A media e':" << opcao5(sequencia);
                        break;
                    }
                    case (6): {
                        opcao6(sequencia);break;
                    }


                    case (7): {
                        cout << "standard deviation is" << opcao7(sequencia) << endl;
                        break;
                    }

    }

}while(opcao!=0);


    return 0;
}
int menu(){int opcao;

cout<<"Analysis of a sequence of integers\n";
cout<<"1- Read a sequence\n"
    <<"2- rite a sequence\n"
    <<"3- Calculate the maximum value\n"
    <<"4- Calculate the minimum value\n"
    <<"5- Calculate the mean value\n"
    <<"6- Histogram\n"
    <<"10- End the program\n"
    <<"Choice ->";cin>>opcao;

    return opcao;
}



void opcao1(){//ler uma sequencia
    cout<<"Here is a sequence of numbers:"
        <<"1;3;6;8;10;15;2;1;4;5";
}

void opcao2(vector<int> &sequencia){int c;//escrever a sequencia
    cout<<"Write a sequence\n";

        while (cin>>c){
            if (c != 0)
                sequencia.push_back(c);
            else { break; }
        }
    }


int opcao3(vector<int> &sequencia){//elemento maximo

int max= *max_element(sequencia.begin(), sequencia.end());
return max;
}

int opcao4(vector<int> &sequencia){//elemento minimo
    int min= *min_element(sequencia.begin(), sequencia.end());
return min;
}


double opcao5(vector<int> &sequencia){//media

    int sum=accumulate(sequencia.begin(), sequencia.end(), 0);
 return sum/sequencia.size();
}


void opcao6(vector<int> &sequencia){//imprimir

for(int c: sequencia) {
    cout << c <<"-";
}

}

double opcao7(vector<int> &sequencia){//standard deviation
double deviation, sum=0, soma; int count=0;

    for(int c: sequencia){

        soma= c- opcao5(sequencia);//sample- media
        sum+=pow(soma, 2);//(sample-media)^2 acrescentar na soma
        count++;//numero de samples
    }
    count=count-1;
deviation= sqrt(sum/count);


    return deviation;

}