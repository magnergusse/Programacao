//
// Created by MAGNER GUSSE on 1/25/2022.
//

#include <iostream>
#include<string>
#include <vector>
#include <fstream>
#include <algorithm>
#include <numeric>
#include <cmath>
#include <iomanip>
using namespace std;



int main(){
ifstream file;int a;
string nome, linha;char h;
cin>>nome>>linha;
cout<<nome<<setfill('-')<<setw(10)<<linha;


    return 0;
}