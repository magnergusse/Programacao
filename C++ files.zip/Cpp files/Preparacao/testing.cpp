//
// Created by MAGNER GUSSE on 1/20/2022.
//

#include <iostream>
#include<string>
#include <vector>
#include <fstream>
#include <algorithm>
#include <numeric>
#include <cmath>
#include <iomanip>
using namespace std;

struct Time{
    int hora, minuto, segundo;
};
struct Student{
    string Nome; int Nmec, Temp;
    Time tempo;
};


int main() {
    ifstream ficheiro(".txt");
    string linha;
    int nums = 0, text = 0, count_num = 0, count_text = 0;

    int flag2=0;
    cout<<"Validating your phone number.....\n";
cin>>linha;
// Checking if number is correct
while(getline(ficheiro,linha)) {
    for (int i = 1; i < linha.length(); i++) {
        if (isdigit(linha[i])) {
            flag2 = 1;
            continue;
        } else {
            flag2 = 0;
            break;
        }
    }
    if (flag2 == 1 && linha.length() == 13 && linha[0]=='+') {
        count_num++;
    } else if (flag2 == 0) {
count_text++;
    } else if (linha.length() != 13) {
        count_text++;
    }

}
cout<<count_text<<" non numbers\n"<<count_num<<"numbers";

    return 0;
}
