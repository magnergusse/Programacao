//
// Created by MAGNER GUSSE on 1/19/2022.
//
#include <iostream>
#include<string>
#include <vector>
#include <fstream>
#include <algorithm>
#include <numeric>
#include <cmath>
#include <iomanip>
using namespace std;

struct Time{
    int hora, minuto, segundo;
};
struct Student{
    string Nome; int Nmec, Temp;
    Time tempo;
};
string filename;



vector<Student>armazenar;
void menu();
Student ask_info();
void listar_tudo(vector<Student>&armazenar);
void listar_ultima(vector<Student>&armazenar);
void guardar(vector<Student>&armazenar);
void listar_temp(vector<Student>&armazenar);
void maior_temp(vector<Student>&armazenar);
void imprimir_file();
double temp_media(vector<Student>&armazenar);
int main(){Student estudante;
    ifstream kelvin;
int opcao;
    do{menu();
        cout<<"Choice->";cin>>opcao;
        switch (opcao) {
            case (1): {ask_info();break;}
            case (2):{
                listar_tudo(armazenar);break;}
            case(3):{maior_temp(armazenar);break;}
            case(4):{
                listar_temp(armazenar);break;}
            case(5):{
                guardar(armazenar);break;}
            case(6):{
                imprimir_file(); break;

            }
            case(7):{
                cout<<"A temperatura media e': "<<temp_media(armazenar);break;
            }
        }

    } while (opcao!=0);

    return 0;
}

void menu(){
    cout<<"1-Ler nova medida de um sensor\n";
    cout<<"2-Imprimir valor das medidas\n";
    cout<<"3-Imprimir hora e temperatura de leitura mais elevada\n";
    cout<<"4-Histograma de temperaturas\n";
    cout<<"5-Guardar ultima medida\n";
    cout<<"6-Imprimir Mmedidas guardadas em Memoria\n";
    cout<<"7-Imprimir Media das temperaturas\n";
    cout<<"0-Terminar O Programa\n";
}
Student ask_info(){Student estudante;//opcao 1


        cout<< "informacao do estudante\n";
        cout<< "Nome:"; cin>> estudante.Nome;
        do{cout<< "Nmec:";
            cin>> estudante.Nmec;} while(estudante.Nmec<100000 || estudante.Nmec>999999);

        do{cout<<"Temp";
            cin>>estudante.Temp;}while(estudante.Temp>50 || estudante.Temp<0);


    do {cout<<"Hora";cin>>estudante.tempo.hora;}while(estudante.tempo.hora<0 || estudante.tempo.hora>23);
    do {cout<<"Minuto"; cin>>estudante.tempo.minuto;} while(estudante.tempo.minuto<0 || estudante.tempo.minuto>=59);
    do {cout<<"Segundo";cin>>estudante.tempo.segundo;} while (estudante.tempo.segundo< 0 || estudante.tempo.segundo>=59);

    armazenar.push_back(estudante);

        return estudante;
}

void listar_tudo(vector<Student> &armazenar){

    cout<<setw(10)<<"Nome"<<setw(15)<<"Nmec"<<setw(15)<<"Temp"<<setw(15)<<"Hora:";

    for(Student c: armazenar){
        cout<<setw(10)<<c.Nome<<setw(15)<<c.Nmec<<setw(15)<<c.Temp<<setw(15)<<c.tempo.hora<<":"<<c.tempo.minuto<<":"<<c.tempo.segundo;
    }

}

void listar_temp(vector<Student>&armazenar){//listagem das temperaturas
    for( Student c: armazenar){
        cout<<c.Temp<<endl;
    }
}

void guardar(vector<Student>&armazenar){//guardar num ficheiro
    ofstream kelvin;

do {
    cout << "FIlename:";
    cin >> filename;
    kelvin.open(filename);
    if(kelvin.is_open()){
        cout<<"Aberto";
    }else cout<<"Nao abriu";


}while(!kelvin.is_open());
    kelvin<<setw(10)<<"Nome"<<setw(15)<<"Nmec"<<setw(15)<<"Temp"<<setw(15)<<"Hora"<<endl;
kelvin<<setw(10)<<armazenar.back().Nome
    <<setw(15)<<armazenar.back().Nmec
    <<setw(15)<<armazenar.back().Temp
    <<setw(15)<<armazenar.back().tempo.hora<<":"
                 <<armazenar.back().tempo.minuto<<":"//armazenar no ficheiro
                 <<armazenar.back().tempo.segundo;

kelvin.close();
}

void listar_ultima(vector<Student>&armazenar){
    cout<<setw(10)<<"Nome"<<setw(15)<<"Nmec"<<setw(15)<<"Temp"<<endl;
    cout<<setw(10)<<armazenar.end()->Nome<<setw(15)<<armazenar.end()->Nmec<<setw(15)<<armazenar.end()->Temp;
}

void maior_temp(vector<Student>&armazenar){int  count=0;
    Student estudante;
    for ( int i=1; i<armazenar.size(); i++){
if (armazenar.at(i).Temp>armazenar.at(count).Temp){             //se o proximo for maior, acrescentar a contagem
                                                            //para saber  posicao do maior
    count=i;//posicao do maior elemento
}

    }
    cout<<"Maior temperatura:\n";
    cout<<setw(10)<<"Nome"<<setw(15)<<"Nmec"<<setw(15)<<"Temp"<<setw(15)<<"Hora"<<endl;
    cout<<setw(10)<<armazenar.at(count).Nome
        <<setw(15)<<armazenar.at(count).Nmec
        <<setw(15)<<armazenar.at(count).Temp //cout do que estiver na posicao da maior tempertura
        <<setw(15)<<armazenar.at(count).tempo.hora<<":"<<armazenar.at(count).tempo.minuto<<":"<<armazenar.at(count).tempo.segundo<<endl;

}


void imprimir_file(){

    ifstream  kelvin(filename);
while(!kelvin.eof()){string linha;
    getline(kelvin, linha);
    cout<<linha<<endl;

}


kelvin.close();
}

double temp_media(vector<Student>&armazenar){int size=0; double soma=0;



    for(int c=0; c<armazenar.size(); c++){
        soma+=armazenar.at(c).Temp;
        size++;
    }
    double media;
media =soma/size;

    return media;

}