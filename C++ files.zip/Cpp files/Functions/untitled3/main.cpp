#include <iostream>
#include <cmath>
using namespace std;

void bad_swap( int x, int y )
{
    printf("x=%d y=%d\n", x, y);
    int tmp = x;
    x = y;
    y = tmp;
    printf("x=%d y=%d\n", x, y);
}

int main() {

}
