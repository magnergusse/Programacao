#include <iostream>
#include <math.h>
#include<stdio.h>
#include <stdlib.h>
#include <cmath>



using namespace std;
double bmi(double m, double h){
    double d;
    d=pow(h,2);
    return( m /d);
}

int main() {
    double a, b;


    cout<<"Massa(kg): ";cin>>a;
    cout<<"altura(m): ";cin>>b;
    double BMI= bmi(a, b);


    if (BMI<18.5){
        cout<<"BMI="<< BMI<<endl<<"->underweight"<<endl;
    }
    else if (BMI>=18.5 && BMI<24.9){
        cout<< "BMI="<<BMI<<endl<<"->Normal weight"<<endl;
    }

    else if (BMI>=25 && BMI<29.9){
        cout<<"BMI="<< BMI<<endl<<"->overweight"<<endl;
    }

    else if (BMI>=30 && BMI<34.9){
        cout<< "BMI="<<BMI<<endl<<"->obese"<<endl;
    }

    else if (BMI>=34.9){
        cout<< "BMI="<<BMI<<endl<<"->extremely obese"<<endl;
    }




    return 0;
}
