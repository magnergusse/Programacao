#include <iostream>
#include <cmath>
using namespace std;
/*int gcd(a, b)
while (b != 0)
t := b
b := a mod b
a := t
return a
*/
int mdc


int main() {



    return 0;
}
