#include <iostream>
using namespace std;
void integer(int a) {
    for (a; a > 0; a--)
    cout<< a<<endl;

}
int main() {
    int b;
    cin>>b;
integer(b);


    return 0;
}