#include <iostream>
#include <cmath>
using namespace std;

double polinom(double x ){


    return (pow(x,2)+ (2*x) + 3);
}


int main() {

    for (double i = 0; i <= 2; i+=0.1) {
        double funcao = polinom(i);
        cout << "Polinomio=" << funcao << endl;
    }


    return 0;
}
