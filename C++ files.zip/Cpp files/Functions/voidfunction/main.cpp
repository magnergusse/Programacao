#include <iostream>
#include<string>
#include<cmath>
using namespace std;

int mag(int a, int b){
return a-b;

}








int main() {
int zed = mag(3,6);

cout<< zed <<endl;

 return 0;
}
