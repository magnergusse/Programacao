#include <iostream>
#include <cmath>
using namespace std;

double funcao(double param1, double param2){
    if (param1>param2){return param1;}
else
return param2;
}

int main() {
    double valor_a, valor_b;
    cout<<"Inserir valor a=";cin>> valor_a;
    cout<<"Inserir valor b=";cin>> valor_b;

    cout<< funcao(valor_a, valor_b);
}
/*para nr a seguir
max2(max2(p1,p2)
 */