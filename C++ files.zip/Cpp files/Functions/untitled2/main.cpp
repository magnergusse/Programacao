#include <iostream>
#include<cmath>
using namespace std;

void print(int n, string text){
    for(int i=0; i<n; i++){
        cout<< text<<endl;
    }
}
int main() {
    print(2, "I need to sleep");
    print(3, "I wanna sleep");

}
