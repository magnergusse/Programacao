#include <iostream>
#include <cmath>
using namespace std;

int read_int_array( int a[], int max_n )
{
    int n;
    cout << "n = ";
    cin >> n;

    for(int i = 0; i < n; i++ )
    {
        cout << "a[" << i << "] = ";
        cin >> a[i];
    }

    return n; // success (note that you should implement a more robust function)
}

int main(void)
{
    int n1, a1[10], n2, a2[10];

    cout << "Introduza o primeiro array" << endl;
    n1 = read_int_array(a1, 10);
    cout << "Introduza o segundo array" << endl;
    n2 = read_int_array(a2, 10);
    if(n1 == n2 && n1 >= 1)
        for(int i = 0; i < n1; i++ )
            cout << "a1[i] + a2[i] = " << (a1[i] + a2[i]) << endl;
    return 0;
}

