#include <iostream>
#include <vector>
#include <map>
#include <string>
#include <set>
#include<cmath>
using namespace std;
int F1(int *A, int *B, int n){
    int count = 0;
    for(int i = 0; i < n; i++){
        if(A[i] == B[n-i-1])
            count++;
    }
    return count;

}
int F2(int *A, int n){
    int J = 0;
    for(int i = 0 ; i < n - 1; i++) {
        if(A[i] < A[i+1])
            J += A[i+1];
    }
    return J;
}

void F3(int *A, int *B, int n){
    *(A + n/2) = *(B + n - 1);
    *(B + 1) = *(A + 2);
}

int main(void){
    int A[] = {1,2,3,3}, B[] = {4,3,2,0}, size = 4;

    int C = F1(A, B, size);
    int D = F2(A, size);
    F3(A, B, size);

    cout << C << endl;
    cout << D << endl;
    for(int i = 0 ; i < 4 ; i++)
        cout << A[i] << "-";
    cout << endl;
    for(int i = 0 ; i < 4 ; i++)
        cout << B[i] << "-";
    cout << endl;
    return 0;
}