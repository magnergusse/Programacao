#include <iostream>
#include <cmath>
using namespace std;
double funcao_g(double x, double a, double b, double c) {
    return a*(pow(x,2)) +(b*x) +c;
}
int main() {
    double valor_a, valor_b, valor_c;


    cout<<"Valor de a=";cin>>valor_a;
    cout<<"Valor de b=";cin>>valor_b;
    cout<<"Valor de c=";cin>>valor_c;


    for (double i = 0; i <= 2; i+=0.1) {
        double funcao = funcao_g(i,valor_a, valor_b, valor_c);
        cout << "Polinomio=" << funcao << endl;
    }



    return 0;
}
