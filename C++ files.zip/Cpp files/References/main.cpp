#include <iostream>
using namespace std;
int main() {


  int a;
cin>>a;
  int &b=a;
  int &c=b;
    cout<<endl<<a<<"**";
    cout<<endl<<b<<"**";
    cout<<endl<<c<<"**";


    bool x= true;
    bool &y=x;

    cout<<endl<<x<<"**";
    cout<<endl<<y<<"**";
    cout<<endl<<&x<<"**";
    cout<<endl<<&y<<"**";



    return 0;
}
