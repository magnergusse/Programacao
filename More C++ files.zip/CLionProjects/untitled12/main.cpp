#include <iostream>
using namespace std;
int main() {
int x;
while (true){
    cout<<"type 1 or 2:";
    cin>>x;
    if (x==1 || x == 2){
        cout<<"finished";
        break;
    }
    else if(x >=7 ){
        cout<< "completed";
        break;
    }
}









        return 0;
}
