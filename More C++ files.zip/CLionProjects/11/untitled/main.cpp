#include <iostream>

    using namespace std;
    int main() {
        int N;
        cout<<"(a)";
        do{
            cout<< "N=";
            cin>>N;
        } while(N<3 || N>15);
        cout<<N<<endl;

        cout<<"(b)";
        cout<< "Multiplos de 4 menores ou iguais ao valor introduzido: ";

        do {

            cout<< 4*1;

            break;}
        while (N<4);
        do {

            cout<< 4*1<< 4*2;

            break;

        }while(N>4 && N<12);


        do {

            cout<< 4*1<< 4*2 <<4*3;


            break;
        }while(N>12 && N<15);
        cout<< endl<< "(c)"<<endl;
        if(N==6)
            cout<<"Eh perfeito";
        else
            cout<<"Nao eh perfeito";


        return 0;
    }

