//
// Created by MAGNER GUSSE on 11/8/2021.
//

#include <iostream>
#include <string>
using namespace std;

int main() {
        int a=7, b=5;
        int sum = a + b;
        cout<< sum;



}

/*
 *
 *
 *
 *
 */