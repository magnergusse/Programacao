#include <iostream>

using namespace std;

int main() {
    float p , tp;
    float n1, n2;
    cout << "p ="; cin>> p; cout<< "*" ; cout << "n1 ="; cin>> n1; cout<< endl;
    cout << "tp ="; cin>> tp; cout<< "*"; cout << "n2 ="; cin>> n2; cout<< endl;

    double final = n1 * p + n2 * tp;

    cout << "Final grade: " << final << endl;

    return 0;
}
