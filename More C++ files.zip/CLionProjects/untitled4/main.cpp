#include <iostream>

using namespace std;

int main() {
    float p , tp;
    const float n1= 0.75, n2= 0.25;
    cout << "p ="; cin>> p; cout<< endl;
    cout << "tp ="; cin>> tp; cout<< endl;

    double final = n1 * p + n2 * tp;

    cout << "Final grade: " << final << endl;

    return 0;
}
