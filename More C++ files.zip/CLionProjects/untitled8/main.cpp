#include <iostream>
#include <string>
using namespace std;

int main() {

    string y ="Verdade ou falso";
    cout<< y;cout<< endl;
    int a;
    cout<< "2*5 >= "; cin>> a;
    bool test= 2*5 >= a;
    cout<< test;
}