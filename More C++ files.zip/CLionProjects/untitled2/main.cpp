#include <iostream>

using namespace std;

int main() {
    int p , tp;
    cout << "p ="; cin>> p; cout<< endl;
    cout << "tp ="; cin>> tp; cout<< endl;

    double final = 0.75 * p + 0.25 * tp;

    cout << "Final grade: " << final << endl;

    return 0;
}
