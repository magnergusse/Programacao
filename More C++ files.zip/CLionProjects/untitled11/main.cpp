#include <iostream>
#include <cmath>
using namespace std;

int main() {
    int N;
    cin>>N;
    int arr[N];
    int total = 0;
    for (int i = 0; i < N; i++) {
        int temp;
        cin >> temp;
        if (temp > 0 && temp <= 10) {
            arr[i] = temp;
            total = total + temp;
        }
        else
        {
            cout << "Entrada invalida." << endl;
            i--;
        }
    }
    int total2 = 0;
    float media = total/N;
    cout<<"A media e "<<media<<endl;
    float DP;
    for (int i = 0; i < N; i++)
    {
        total2 = total2 + pow(arr[i]-media,2);
    }
    DP = sqrt(total2/N);
    cout<<"O desvio padrao e "<<DP<<endl;
    cout<<"Os valores acima da media sao: ";
    for (int i = 0; i < N; i++)
    {
        if (arr[i] > media)
            cout<<arr[i]<<" ";
    }
    return 0;
}
0