#include <iostream>
#include <string>
using namespace std;
string str1(string palavra) {

    for (int i = palavra.size() - 1; i <= palavra.size(); i--) {
        cout << palavra[i] << endl;
    }
}

int main() {
string palavra1;
cout<<"Insere um string qualquer: ";
getline(cin, palavra1);
    str1(palavra1);


return 0;
}
