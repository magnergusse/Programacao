#include <iostream>
#include<iomanip>
#include <cmath>
#include <vector>
using namespace std;
struct valores{
    int count=-1;
    double distance=0;
};
typedef struct{
    double y;
    double x;
}point2D_t;


void ler_ponto(point2D_t &ponto);

void contar_vezes(point2D_t &ponto);

int main() {

    point2D_t ponto;
    contar_vezes(ponto);

    return 0;
}

void contar_vezes(point2D_t &ponto) {
    valores values;
    int i = 0;
    vector<double> list;
    while(ponto.x!=0 || ponto.y!=0){
        ler_ponto(ponto);
        values.count++;
        values.distance=sqrt(pow(ponto.x,2)+(pow(ponto.y, 2)));
        cout<<" D="<<values.distance<<endl;
        list.push_back(values.distance);
    }

    cout<<"Pontos diferentes de (0;0) sao:"<<values.count<<endl;
    double sum = 0;

    for (double value : list) {
        sum += value;
    }
    cout<< "Soma das distancias="<<sum<<endl;
}

void ler_ponto(point2D_t &ponto) {
    cout << "Insere ponto\n";
    cout<<"X=";cin>> ponto.x;
    cout<<"Y=";cin>>ponto.y;
    cout<<"(" << setprecision(3)<<fixed <<showpos<< ponto.x ;
    cout<<";"<<setprecision(3)<<fixed<<showpos<<ponto.y <<")\n";
}
