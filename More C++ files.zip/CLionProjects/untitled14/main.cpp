#include <iostream>
using namespace std;
int main() {

    int N, num;

 do{
     cout<< "quantos nrs: ";
     cin>>N;
 } while(N<1 || N>10);
int arr[N];
int x=0;
for(; x<N;x++) {
    cout << "insere o numero: ";
    cin >> num;
    arr[x] = num;
}
for(x-=1; x>=0; x--){
    cout<< arr[x]<< endl;

}




    return 0;
}
