#include <iostream>
using namespace std;


int main() {
int entrada;
int arr[50];
    cout<< "choice";

while(entrada>0 && entrada<100){
    cin>> entrada;
    if (entrada >0){

        cout<< "done";
        break;
    }

    else if (entrada){}



}





    return 0;
}
