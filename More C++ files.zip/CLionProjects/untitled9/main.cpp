#include <iostream>
#include <string>
int main () {
    bool test = !(false && true);


}