#include <iostream>
#include <string>
using namespace std;
int main() {
    int y, x, a;

    cout << "Hello, World!" << endl;
    cout << "Fuck y'all" << endl;
    y = 1;
    x = 5;
    a = 9;
    cout << x << endl;
    cout << y << endl;
    cout << a;


    float b= 3.1 , c= 5.5 , d=6.3;

    cout <<c<<endl;
    cout <<b<<endl;
    cout <<d <<endl;

    string f ="magner";
            cout<<f<<endl;
     bool m=false, k=true;
     cout<<k<<endl;
     cout<<m;
    return 0;
}