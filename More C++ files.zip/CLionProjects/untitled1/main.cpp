#include <iostream>
#include <string>
using namespace std;
int main() {
   int num1, num2;
        cout << "enter a number:" ;
        cin>> num1;
        cout << "enter another number:" ;
        cin>> num2;
   int sum= num1 + num2;
   cout<< "The sum is: " <<sum - 1;

string s;
cin>> s;
cout<<s;



}
