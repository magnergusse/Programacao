#include <iostream>
#include <string>
using namespace std;

int main() {
   float a=8, b;
    a++;
   cout<< "segundo nr"; cin>> b;



    float sum = a * b;
    cout<< sum;



}
