//
// Created by MAGNER GUSSE on 1/25/2022.
//
#include <iostream>
#include<fstream>
#include<iomanip>
#include<string>
#include <vector>
#include<cmath>
using namespace std;
struct student{
    string ipadress; double temp;
};
string filename;//ira armazenar nome do ficheiro
vector<student>guardar;
void readmeasurement(const student&);
bool menu();
void histogram(vector<student>&guardar);
void savemeasuremnts(vector<student>&gurdar);
void print_file();
void print_range(vector<student>&guardar);


int main(){
    student estudante; bool opcao;
bool opcao1;
    do{
        opcao=menu();

        switch (opcao) {
            case (1): {readmeasurement(estudante);break;}
            case (2):{print_file();break;}
            case(3):{
                print_range(guardar);break;}
            case(4):{
                savemeasuremnts(guardar);break;}
            case(5):{
                histogram(guardar);break;}
            case(6):{cout<<"hahaha"; break;
            }
        }

    } while (opcao!=0);


    return 0;
}
bool menu(){int opcao;
    cout<< "Bem vindo ao portal de seguranca do DETI\n";
    cout<<"1-Ler nova medida de um sensor\n";
    cout<<"2-Imprimir valor das medidas guardadas no file\n";
    cout<<"3-Imprimir occorencias por range\n";
    cout<<"4-save in file\n";
    cout<<"5-histograma completo\n";
    cout<<"0-Terminar O Programa\n";
    cout<<"Choice->";cin >>opcao;

    return opcao;
}


void readmeasurement(const student&){//inserir dados
    student estudante;int valid;//para validar a estrutura do IPadress
    cout<<"Inserir dados do(temperatura/numero) \n";

    do{
        cout<<"Temp:";
        cin>>estudante.temp;
    }while(estudante.temp>40 || estudante.temp<0);//temperatura maior que 0 e menor que 40

cin.ignore();
    cout<<"Input number in the folowing format\"xxxx xxxx xxxx xxxx\" \n";
    do {

        cout<<"make sure to include spaces\n";
        cout << "inserir number: \n";
        getline(cin, estudante.ipadress);//atribuir IP a variavel

            cout<<estudante.ipadress<<endl;
        cout<<estudante.ipadress.length()<<endl;

        if(estudante.ipadress.length()==19 && estudante.ipadress[4]==' '&& estudante.ipadress[9]==' '&&estudante.ipadress[14]==' '){//condicoes para que cumpra com o formato

            for(int i=0;i<19; i++ ){
               if(i==4 || i==9 || i==14){break;}//excepcoes no loop
                else if(isdigit(estudante.ipadress[i])){ valid=1;}//se os carateres forem inteiros retornar 1
                else if(!isdigit(estudante.ipadress[i])){valid=0; break;}//se nao forem inteiros retornar 0 imediatamente

        }
    }
        else{valid=0;}//se nao cumprir as condicoes nao e'valido


        if(valid==1){cout<<"Succesfull\n";}
        else if(valid==0){cout<<"Oh oh, something's wrong\n";}

} while (valid==0);//repetir enquanto estiver a retornar 0


guardar.push_back(estudante);//se cumprir com as condicoes pode adicionar os dados no vetor
}

void histogram(vector<student>&guardar){//imprimir histograma de registos
    for(student c: guardar ){
        cout<<"IP: "<<c.ipadress<<setfill('-' )<<setw(10)<<"Temp: "<<c.temp<<endl;
    }
}
void savemeasuremnts(vector<student>&gurdar){//guardar valores guardados no vetor para o ficheiro
    int menor;//valor minimo a guardar
    ofstream file;
    do{cout<<"create/ open a file\".txt\" \n";//inserir nome do ficheiro
        cout<<"filename: ";cin>>filename;
        file.open(filename);
        if(file.is_open()){cout<< "file created\n";}
        else if(!file.is_open()){ cout<<"Try again";
        }
    }while(!file.is_open());//enquanto o ficheiro nao abrir

    cout<<"save measurements!\n";
    cout<<"Guardar maiores que: ";cin>>menor;
    file<<"temp"<<setfill('-')<<setw(25)<<"Numero\n";
    for(int i=0; i<guardar.size(); i++){
if(guardar.at(i).temp>=menor){
file<<guardar[i].temp<<setfill('-')<<setw(25)<<guardar[i].ipadress<<endl;

}
    }

file.close();//fechar o ficheiro

}

void print_file(){//imprimir o que esta no ficheiro


    ifstream file(filename);//abrir o ficheiro ja criado
    string linha;//armazenar cada linha do ficheiro

    while(!file.eof()){//enquanto nao estiver no fim do ficheiro
        getline(file, linha);
        cout<<linha<<endl;//imprimir cada linha
    }
file.close();
}


void print_range(vector<student>&guardar){// imprimir ocorrencias para cada range de temperaturas
    int zeros=0, jide=0, twentie=0, trinta=0;//0-10; 10-20; 20-30; 30-40

    for(student c: guardar){
        if(c.temp<10){zeros++;}//<10 contar
        else if(c.temp>=10 && c.temp<20){jide++;}//10-20 contar
        else if(c.temp>=20&& c.temp<30){twentie++;}//20-30 contar
        else if(c.temp>=30){trinta++;}//+30 contar
    }
    cout<<"from 0 to 10: "<<zeros<<" ocurrencies\n";
    cout<<"from 10 to 20: "<<jide<<" ocurrencies\n";
    cout<<"from 20 to 30: "<<twentie<<" ocurrencies\n";
    cout<<"from 30 to 40: "<<trinta<<" ocurrencies\n";

}
