// Validate a phone number in C++

#include<iostream>

#include <fstream>
    using namespace std;

void readIp();
int main()
    {
string nome; int contar, numero=0, outros=0;

ifstream haha;
 do{cout<<"nome";cin>>nome;
 haha.open(nome);
 }while(!haha.is_open());

 while(getline(haha,nome)){//enquanto estiver a retirar a linha
     for(int i=1; i<nome.length(); i++){//deve comecar da posicao 1
         if (isdigit(nome[i])){//se forem digitos todos os elementos, deve retornar 1
             contar=1;
         }
         else if(!isdigit(nome[i])) {//se no forem retornar 0
             contar=0; break;
         }
     }
     if (contar==1 && (nome.length()>10 && nome.length()<14) && nome[0]=='+'){//condicao para que seja numero de telefone
         numero+=1;//se for, aumenta a contagem
     }
     else{//se nao for, aumenta outra contagem
         outros+=1;
     }
 }
 cout<<"There are "<<numero<<"phone numbers\n";
 cout<<"There are "<<outros<<"non phone numbers\n";


        return 0;
    }

    void readIp(){
        struct estudante{
            int temp; string IP;
        };
    }

