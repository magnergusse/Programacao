//
// Created by MAGNER GUSSE on 1/27/2022.
//

#include <iostream>
#include<fstream>
#include<iomanip>
#include<string>
#include <vector>
#include<cmath>
using namespace std;

struct dados{
    int Nmec; string *numero;
     numero= new string[16];
};
void pedir(dados){dados Dados;
    cout<<"isert nmec";cin>>Dados.Nmec;

}

int main(){


}