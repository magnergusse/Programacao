#include <iostream>
#include <random>
#include <ctime>
using namespace std;

int main() {
    int arr[50];
    int entrada = 1;
    int j = 0;
    while (entrada>0 && entrada<10)
    {
        cout<<"Analysis of a sequence of integers"<<endl;
        cout<<" 1 - Read a sequence"<<endl;
        cout<<" 2 - Write a sequence"<<endl;
        cout<<" 3 - Calculate the maximum value"<<endl;
        cout<<" 4 - Calculate the minimum value"<<endl;
        cout<<" 5 - Calculate the mean value"<<endl;
        cout<<" 6 - Test if the sequence includes only even numbers"<<endl;
        cout<<"10 - End the program"<<endl<<"Choice ->";
        cin>>entrada;
        switch (entrada) {
            case 1:
                cout << "Introduz os valores: ";
                for (int i = 0; i < 50; i++) {
                    int temp;
                    cin >> temp;
                    if (temp != 0)
                        arr[i] = temp;
                    else
                        break;
                    j = i;
                }
                cout<<endl;
                break;
            case 2:
                srand(static_cast<int>(time(0)));
                cout << "Quantos valores queres? " << endl;
                int temp;
                cin >> temp;
                cout<<"A sequencia e: ";
                for (int i = 0; i < temp; i++) {
                    arr[i] = rand() % 1000;
                    cout<<arr[i]<<" ";
                    j = i;
                }
                cout<<endl<<endl;
                break;
            case 3:
                int max;
                max = arr[0];
                for (int i = 1; i < j; i++)
                {
                    if (arr[i] > arr[i-1])
                        max = arr[i];
                }
                cout<<"O valor maior e "<< max<<endl<<endl;
                break;
            case 4:
                int min;
                min = arr[0];
                for (int i = j-1; i >= 0; i--)
                {
                    if (arr[i] < arr[i+1])
                        min = arr[i];
                }
                cout<<"O valor menor e "<< min<<endl<<endl;
                break;
            case 5:
                int total;
                for (int i=0; i<j; i++)
                    total += arr[i];
                cout<<"A media e "<<total/(j+1)<<endl<<endl;
                break;
            case 6:
                int cont = 0;
                for (int i = 0; i < j; i++)
                {
                    if (arr[i] % 2 != 0 )
                        cont++;
                }
                if (cont > 0)
                    cout<<"Nao existem so pares";
                else
                    cout<<"Existem so pares";
                cout<<endl<<endl;
                break;
        }
    }
    cout<<arr[2];
    return 0;
}
